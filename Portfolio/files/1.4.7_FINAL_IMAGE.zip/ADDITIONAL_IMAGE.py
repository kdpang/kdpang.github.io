'''
Image Artist 1.4.7
Kayla Kim & Kelly Pang
14/12/16
'''

import PIL
import PIL.ImageOps
import random

# Makes data values of image negative
def sad_negative():
    sad = PIL.Image.open('sad_man.png')
    # Used PIL.ImageOps to invert the image
    inverted_image = PIL.ImageOps.invert(sad)
    inverted_image.save('negative_sad.png')
    
    return inverted_image

# "Breaks" images into pieces and saves seperately
def break_img():
    # Variables created for dimensions
    width, height = inverted_image.size
    piece_width = width / 2
    piece_height = height / 2
    
    # Creates the seperated pieces of the image in 1/4ths
    piece_1 = inverted_image.crop((0,0,piece_width,piece_height))
    piece_2 = inverted_image.crop((piece_width,0,width,piece_height))
    piece_3 = inverted_image.crop((0,piece_height,piece_width,height))
    piece_4 = inverted_image.crop((piece_width, piece_height,width,height))
    
    # Saves all pieces
    piece_1.save('piece_1.png')
    piece_2.save('piece_2.png')
    piece_3.save('piece_3.png')
    piece_4.save('piece_4.png')
    
    return width, height, piece_width, piece_height

# Makes a new image from all pieces
def merge_all():
    # Opens all image pieces
    p_1 = PIL.Image.open('piece_1.png')
    p_2 = PIL.Image.open('piece_2.png')
    p_3 = PIL.Image.open('piece_3.png')
    p_4 = PIL.Image.open('piece_4.png')

    # Makes empty mask to paste image pieces
    final_img = PIL.Image.new('RGBA',(width,height))
    
    # Pastes pieces onto empty mask out of order
    final_img.paste(p_4,(0,0))
    final_img.paste(p_3,(piece_width,0))
    final_img.paste(p_2,(0,piece_height))
    final_img.paste(p_1,(piece_width,piece_height))
    
    # Saves final piece
    final_img.save('final_image.jpg')

# Return
inverted_image = sad_negative()
width, height, piece_width, piece_height = break_img()

# Functions
sad_negative()
break_img()
merge_all()
