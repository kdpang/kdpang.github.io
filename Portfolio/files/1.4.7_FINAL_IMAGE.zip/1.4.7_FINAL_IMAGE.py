'''
AP CSP Final:1.4.7 Image Artist 
Names: Kelly Pang, Kayla Kim
Period 3
Theme: Isolation
'''

import PIL
import matplotlib.pyplot as plt 
import numpy as np
import os.path  
import PIL.ImageDraw             
from PIL import Image
import PIL.ImageOps

# Open the files in the same directory as the Python script
directory = os.path.dirname(os.path.abspath(__file__))  
happy_file = os.path.join(directory, 'happy_family.png')
happy_img = PIL.Image.open(happy_file)
width, height = happy_img.size
sad_file = os.path.join(directory, 'modified_man.png')
sad = PIL.Image.open(sad_file)

# Show the family image in a new Figure window
#def family():
fig, axes = plt.subplots(1, 1)
axes.imshow(happy_img, interpolation='none')

# Open, resize, and display the shattered glass image
shatter_file = os.path.join(directory, 'broken_glass.png')
shatter_img = PIL.Image.open(shatter_file)
shatter_new = shatter_img.resize((width, height)) #width and height measured in plt
fig2, axes2 = plt.subplots(1, 2)
axes2[0].imshow(shatter_img)
axes2[1].imshow(shatter_new)
fig2.show() # Shows the old image and the resized image
shatter_new.save("resized_shatter.png", "PNG")

# Merge the resized shattered glass image with the happy image
background = Image.open("happy_family.png")
overlay = Image.open("resized_shatter.png")
background = background.convert("RGBA")
overlay = overlay.convert("RGBA")
merged_img = Image.blend(background, overlay, 0.35) # Number represents the overlay being more transparent than the background
merged_img.save("merge.png","PNG")
fig3, axes3 = plt.subplots(1,1)
axes3.imshow(merged_img)
fig3.show()

#sad_man = sad.crop((left,upper,right,lower))
sad_man = sad.crop((120,155,300,375))
merged_img.paste(sad_man, (800,440)) # Paste the image of the sad man onto the corner of the shattered family photo
fig4, axes4 = plt.subplots(1,1)
axes4.imshow(merged_img)
fig4.show()

# Change the white background of the image 'modified_man.png' and paste the modified image on the shattered family photo
def change_background(image):
    if type(image) == str:
        image = Image.open(image)
    width, height = image.size 
    pixel = image.load()
    for y in range(height): # Iterate through each row
        for x in range(width): #Iterate through each pixel in the column
            if pixel[x,y]==(255,255,255,255):
                pixel[x,y]=(50,50,50,255) #greyish color (and note: changing the alpha channel oddly doesn't do anything for the transparency in this code, which we were puzzled about because we wanted to change the white background to transparent)
    image = image.crop((120,155,300,375))
    merged_img.paste(image, (800,440))
    fig5, axes5 = plt.subplots(1,1)
    axes5.imshow(merged_img)
    fig5.show()
    return image

'''
# One of our ideas: paste the broken family photo on the wall of the room the lonely man is curled up in.
# Make the shattered family photo smaller in dimension
#def resize_family(merged_img):
family_photo = merged_img.resize((160, 120))
family_photo.save("family_photo.png","PNG")
family_photo.show()
#return family_photo

# Paste shattered family photo onto the sad man's wall
#def final_image(family_photo):
sad.paste(family_photo, (50,50)) 
fig4, axes4 = plt.subplots(1,1)
axes4.imshow(sad)
fig4.show()
'''

'''    
family()
resize_glass()
resize_family(merge_shatter())
family_photo=resize_family(merged_img)
'''